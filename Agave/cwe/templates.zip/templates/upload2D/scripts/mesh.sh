#!/bin/bash

SLICE_VAL=`python $PYTHONDIR/Templater.py getval slicePlane`
SLICE_ANG=`python $PYTHONDIR/Templater.py getval sliceAngle`
GEO_CHOOSE=`python $PYTHONDIR/Templater.py getval geoChoose`
if [ "$GEO_CHOOSE" == "uploaded" ]
then
    MESHFILE=$STARTINGDIR/$EXTRAFILE
else
    MESHFILE=$DATA_FOLDER/$GEO_CHOOSE
fi

cd constant/polyMesh/

echo "Full Mesh File Path:"
echo $MESHFILE

python $PYTHONDIR/GetData.py $MESHFILE upload.json
STOP=$?
if [ $STOP -ne 0 ]
then
    echo "Unable to retrive raw mesh file."
    exit $STOP
fi

python $PYTHONDIR/Slice2D.py upload.json sliced.json $SLICE_VAL z $SLICE_ANG
STOP=$?
if [ $STOP -ne 0 ]
then
    echo "Unable to slice mesh."
    exit $STOP
fi

python $PYTHONDIR/Data2geo.py sliced.json sliced.geo params.txt 
STOP=$?
if [ $STOP -ne 0 ]
then
    echo "Unable to convert to geo file."
    exit $STOP
fi

chmod 700 $STARTINGDIR/utils/gmsh
ibrun $STARTINGDIR/utils/gmsh -2 sliced.geo
STOP=$?
if [ $STOP -ne 0 ]
then
    echo "Unable to run gmsh."
    exit $STOP
fi

python $PYTHONDIR/Msh2of.py sliced.msh . params.txt
STOP=$?
if [ $STOP -ne 0 ]
then
    echo "Unable to convert to OpenFOAM mesh."
    exit $STOP
fi

cd ../..
mkdir -p stats
mv constant/polyMesh/stats.mesh stats

exit 0
