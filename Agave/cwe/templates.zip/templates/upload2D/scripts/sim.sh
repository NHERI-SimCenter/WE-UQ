#!/bin/bash

TURB_MODEL=`python $PYTHONDIR/Templater.py getval turbModel`

# Load the OpenFoam module
#module rm python 
#ml intel/18.0.0 impi/18.0.0 
#module load openfoam
source /scratch/01255/siliu/sourceof6
#LD_LIBRARY_PATH=$FOAM_INST_DIR/OpenFOAM-5.0/platforms/linux64IccDPInt32Opt/lib:$LD_LIBRARY_PATH
#export LD_LIBRARY_PATH=$FOAM_INST_DIR/OpenFOAM-5.0/platforms/linux64IccDPInt32Opt/lib/intel64:$LD_LIBRARY_PATH

decomposePar > decomposePar.log

if [ "$TURB_MODEL" == "laminar" ]
then
    ibrun -n 16 -o 0 icoFoam -parallel > sim.log
else
    ibrun -n 16 -o 0 pisoFoam -parallel > sim.log
fi

STOP=$?
if [ $STOP -ne 0 ]
then
    echo "Unable to run simulation."
    exit $STOP
fi

reconstructPar
rm processor* -rf

echo "Sim complete"

foamToVTK
zip -r1 VTK.zip VTK
rm -rf VTK
echo "VTK visuals produced and compressed."

exit 0
